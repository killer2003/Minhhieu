package com.example.news.adapter;

public interface OnItemNews {
    void setOnItemNewsSmall(int i);

    void setOnItemNewsLarge(int i);
}
