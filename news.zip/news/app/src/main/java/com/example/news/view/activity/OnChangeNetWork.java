package com.example.news.view.activity;

public interface OnChangeNetWork {
    void OnChangeNetWork(final boolean isNetWork);
}
